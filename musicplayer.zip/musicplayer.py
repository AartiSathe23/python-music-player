from tkinter import *
import time 
from tkinter import filedialog
from pygame import mixer
import os
from PIL import Image,ImageTk

mixer.init()
class Player:
    def __init__(self,root):
        self.root=root
        self.root.title("Mp3 Player")
        self.root.geometry('400x450+500+200')
        self.root.configure(bg="cornsilk3")
        root.resizable(False,False)

        lower_frame=Frame(self.root,bg="white",width=400,height=80)
        lower_frame.place(x=0,y=220)

        # image_icon=ImageTk.PhotoImage(file="musicplayer.png")
        # root.iconphoto(False,image_icon)

        Menu=ImageTk.PhotoImage(file="vinylplayer.jpeg")
        Label(self.root,image=Menu).place(x=20,y=20,width=360,height=180)

        lower2_frame=Frame(self.root,width=400,height=120)
        lower2_frame.place(x=0,y=330)
        
        browse_button=Button(self.root,text="Browse music",font=("Arial",12,"bold"),bg="gray35",fg="gold",bd=2,relief=RIDGE,width=20,cursor="hand2",command=self.AddMusic)
        browse_button.place(x=0,y=300)

        scroll=Scrollbar(lower2_frame,orient=VERTICAL)
        self.Playlist=Listbox(lower2_frame,width=100,font=("Times new roman",10),bg="lightsalmon2",fg="black",selectbackground="steelblue4",cursor="hand2",yscrollcommand=scroll.set)
        scroll.config(command=self.Playlist.yview)
        scroll.pack(side=RIGHT,fill=Y)
        self.Playlist.pack(side=LEFT,fill=BOTH)

        exit_button=Button(self.root,text="Exit",font=("Arial",12,"bold"),bg="gray35",fg="gold",bd=2,relief=RIDGE,width=20,cursor="hand2")
        exit_button.place(x=200,y=300)
        
        # play=ImageTk.PhotoImage(file='button.jpg')
        # image_label=Label(image=play)
        # play_btn=Button(lower_frame,image=image_label,borderwidth=2)
        # play_btn.pack(pady=10)
        # my_label=Label(self.root,text='')
        # my_label.pack(pady=10)
        
        play_btn_image=Image.open("play.jpg")
        height=50
        width=50
        resize_btn=play_btn_image.resize((width,height))
        resize_btn.show()
        play_btn=ImageTk.PhotoImage(resize_btn)
        play=Button(lower_frame,image=play_btn,bg="white",bd=0,height=50,width=50,borderwidth=0,command=self.PlayMusic,cursor="hand2")
        play.place(x=175,y=15)

        pause_btn_image=Image.open("pause.jpeg")
        height=50
        width=50
        resize1_btn=pause_btn_image.resize((width,height))
        # resize1_btn.show()
        pause_btn=ImageTk.PhotoImage(resize1_btn)
        pause=Button(lower_frame,image=pause_btn,bg="white",bd=0,height=50,width=50,borderwidth=0,command=self.PauseMusic,cursor="hand2")
        pause.place(x=50,y=15)

        volume_btn_image=Image.open("volume.png")
        height=50
        width=50
        resize2_btn=volume_btn_image.resize((width,height))
        # resize2_btn.show()
        volume_btn=ImageTk.PhotoImage(resize2_btn)
        volume=Button(lower_frame,image=volume_btn,bg="white",bd=0,height=50,width=50,borderwidth=0,cursor="hand2")
        volume.place(x=300,y=15)


    def AddMusic(self):
        path=filedialog.askdirectory()
        if path:
         os.chdir(path)
         songs=os.listdir(path)

         for song in songs:
            if song.endswith(".mp3"):
               self.Playlist.insert(END,song)

    def PlayMusic(self):
       music_name=self.Playlist.get(ACTIVE)
       print(music_name(ACTIVE))
       mixer.music.load(self.Playlist.get(ACTIVE))
       mixer.music.play()

    def PauseMusic(self):
       mixer.music.pause()
root=Tk()
obj=Player(root)
root.mainloop()
